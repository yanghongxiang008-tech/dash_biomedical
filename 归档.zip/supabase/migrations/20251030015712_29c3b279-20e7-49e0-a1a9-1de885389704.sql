-- Clear stock price cache data for 2025-10-29
DELETE FROM stock_price_cache WHERE date = '2025-10-29';